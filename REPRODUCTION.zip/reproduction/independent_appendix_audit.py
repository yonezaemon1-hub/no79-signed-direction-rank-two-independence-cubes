"""Fresh limited Appendix A check; never imports the author's verifier."""
from collections import deque
from itertools import product

def fib(t):
    a,b=0,1
    for _ in range(t): a,b=b,a+b
    return a

def vertices(model,n,k):
    out=[]
    for bits in product((0,1), repeat=n):
        if model==75: good=all(bits[i]+bits[i+1]<2 for i in range(n-1))
        elif model==76: good=all(bits[i]+bits[(i+1)%n]<2 for i in range(n))
        elif model==77: good=all(sum(bits[i:i+k])<k for i in range(n-k+1))
        else: good=all(sum(bits[(i+j)%n] for j in range(k))<k for i in range(n))
        if good:out.append(sum(v<<i for i,v in enumerate(bits)))
    return set(out)

def check(model,n,k):
    v=vertices(model,n,k)
    for x in v:
        assert all((x ^ (1<<i)) in v for i in range(n) if x & 1<<i)
    edges={(x,x|1<<i) for x in v for i in range(n) if not x&1<<i and x|1<<i in v}
    if model==76:
        selected={(x,y) for x,y in edges if (x^y)&7 and (x&7)==0}
        target=fib(n)+fib(n-2)
    else:
        selected={(x,y) for x,y in edges if (x^y)&((1<<0)|(1<<(n-1)))}
        if model==75:target=2*fib(n)
        elif model==77:target=2*(len(v)-len(vertices(model,n-1,k)))
        else:target=2*(len(v)-len(vertices(77,n-1,k)))
    assert len(selected)==target,(model,n,k,len(selected),target)
    adj={x:[] for x in v}
    for a,b in edges:adj[a].append(b);adj[b].append(a)
    # Independent all-source BFS followed by shortest-path DAG max-weight DP.
    for start in v:
        dist={start:0};q=deque([start])
        while q:
            x=q.popleft()
            for y in adj[x]:
                if y not in dist:dist[y]=dist[x]+1;q.append(y)
        assert all(dist[y]==(start^y).bit_count() for y in v)
        score={start:0}
        for x in sorted(v,key=lambda t:dist[t]):
            for y in adj[x]:
                if dist[y]==dist[x]+1:
                    score[y]=max(score.get(y,-1),score[x]+(tuple(sorted((x,y))) in selected))
        assert max(score.values())<=2,(model,n,k,start,max(score.values()))

counts={}
for model,params in [(75,[(n,0) for n in range(2,9)]),(76,[(n,0) for n in range(3,9)]),(77,[(n,k) for k in range(3,6) for n in range(2,9)]),(78,[(n,k) for k in range(3,6) for n in range(k,9)])]:
    for n,k in params:check(model,n,k)
    counts[model]=len(params)
print('LIMITED INDEPENDENT APPENDIX AUDIT PASS',counts,'total',sum(counts.values()))
