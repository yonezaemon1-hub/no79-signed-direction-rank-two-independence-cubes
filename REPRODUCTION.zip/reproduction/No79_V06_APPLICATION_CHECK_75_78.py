"""Finite spot checks for the application appendix to Research No.79.
This does NOT prove the global upper bounds or equality classifications.
Standard library only, frozen original packages unchanged.
"""
from functools import lru_cache

@lru_cache(None)
def fib(n):
    a,b=0,1
    for _ in range(n): a,b=b,a+b
    return a

@lru_cache(None)
def words(n, model, k=0):
    res=[]
    for x in range(1<<n):
        b=[(x>>i)&1 for i in range(n)]
        if model=='75':
            valid=all(not(b[i] and b[i+1]) for i in range(n-1))
        elif model=='76':
            valid=all(not(b[i] and b[(i+1)%n]) for i in range(n))
        elif model=='77':
            valid=all(not all(b[j:j+k]) for j in range(n-k+1))
        elif model=='78':
            valid=all(not all(b[(i+j)%n] for j in range(k)) for i in range(n))
        else: raise AssertionError(model)
        if valid: res.append(x)
    return tuple(res)

def is_downset(v):
    a=set(v)
    for x in v:
        y=x
        while y:
            lowest=y&-y
            assert x^lowest in a
            y-=lowest
    return True

def selected_edge_classes(n, v, dirs):
    a=set(v)
    return {(x^(1<<i),x) for i in dirs for x in v if (x>>i)&1 and (x^(1<<i)) in a}

def max_geodesic_selected_edges(n,v,edges):
    # Downset => Hamming-isometric. Dynamic programming on shortest-path DAG to each target.
    a=set(v)
    es={frozenset(e) for e in edges}
    best=0
    for target in v:
        dp={target:0}
        for x in sorted(v,key=lambda x:(x^target).bit_count()):
            if x==target: continue
            choices=[]
            for i in range(n):
                if not (((x^target)>>i)&1): continue
                y=x^(1<<i)
                if y in a:
                    choices.append(dp[y]+int(frozenset((x,y)) in es))
            assert choices, ('non-isometric?',n,x,target)
            dp[x]=max(choices)
            best=max(best,dp[x])
    return best

checks=0
for model in ['75','76','77','78']:
    if model=='75':pars=[(n,0) for n in range(2,9)]
    if model=='76':pars=[(n,0) for n in range(3,9)]
    if model=='77':pars=[(n,k) for k in range(3,6) for n in range(2,9)]
    if model=='78':pars=[(n,k) for k in range(3,6) for n in range(k,9)]
    for n,k in pars:
        v=words(n,model,k)
        assert is_downset(v)
        sizes=[sum((x>>i)&1 for x in v) for i in range(n)]
        if model=='75':
            S=selected_edge_classes(n,v,{0,n-1})
            assert len(S)==2*fib(n)
        elif model=='76':
            # 3-direction 000-core radial family, not the union of 3 complete classes.
            a=set(v)
            S={(x^(1<<i),x) for i in range(3) for x in v
               if (x>>i)&1 and all(not((x>>j)&1) for j in range(3) if j!=i)
               and (x^(1<<i)) in a}
            assert len(S)==fib(n)+fib(n-2)
            if n>=5: assert len(S)>2*fib(n-1)
        elif model=='77':
            S=selected_edge_classes(n,v,{0,n-1})
            a=len(v); a1=len(words(n-1,'77',k))
            assert len(S)==2*(a-a1)
        else:
            S=selected_edge_classes(n,v,{0,1})
            a=len(v); a1=len(words(n-1,'77',k))
            assert len(set(sizes))==1 and len(S)==2*(a-a1)
        assert max_geodesic_selected_edges(n,v,S)<=2, (model,n,k)
        checks+=1
    print('PASS model',model,'parameter cases',len(pars))
print('PASS TOTAL PARAMETER CASES',checks)
print('NOTE global upper bounds and equality uniqueness not checked')
