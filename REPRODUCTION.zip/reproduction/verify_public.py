#!/usr/bin/env python3
"""Author-side finite corroboration; Python 3.10+, standard library only."""
from itertools import combinations, permutations, product
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
from io import BytesIO
from collections import deque
R=Path(__file__).resolve().parent
def digest(x): return sha256(x).hexdigest()
def triangle_free(n,mask,pairs):
    return all(mask&t!=t for t in [sum(1<<pairs.index(e) for e in combinations(c,2)) for c in combinations(range(n),3)])
def census(n,E):
    deg=[0]*n
    for i,j in E:deg[i]+=1;deg[j]+=1
    em=[(1<<i)|(1<<j) for i,j in E];full=(1<<n)-1
    tau=min(t.bit_count() for t in range(1<<n) if all(t&e for e in em))
    # Enumerate every partition, independently of any constructive proof.
    cost=min(t.bit_count()+sum(t&e==e or (full^t)&e==e for e in em) for t in range(1<<n))
    assert cost>=tau
    return tau,cost,deg

def direct_opt(n,E):
    V=[0]+[1<<i for i in range(n)]+[(1<<i)|(1<<j) for i,j in E]
    edges=list((x,y) for x,y in combinations(V,2) if (x^y).bit_count()==1)
    adj={x:[] for x in V}
    for x,y in edges:adj[x].append(y);adj[y].append(x)
    # BFS distances on actual graph, no previous bitwise triple criterion.
    dist={}
    for x in V:
        dx={x:0};q=deque([x])
        while q:
            y=q.popleft()
            for z in adj[y]:
                if z not in dx:dx[z]=dx[y]+1;q.append(z)
        for y in V:dist[x,y]=dx[y]
    forb=[]
    for ids in combinations(range(len(edges)),3):
        bad=False
        for order in permutations(ids):
            for bits in product((0,1),repeat=3):
                (a,b),(c,d),(e,f)=[tuple(reversed(edges[i])) if bit else edges[i] for i,bit in zip(order,bits)]
                if dist[a,f]==3+dist[b,c]+dist[d,e]:bad=True;break
            if bad:break
        if bad:forb.append(sum(1<<i for i in ids))
    # Exact exhaustive branching on each violated triple; memoized deletion sets.
    from functools import lru_cache
    @lru_cache(None)
    def opt(m):
        for t in forb:
            if m&t==t:
                return max(opt(m^(1<<i)) for i in range(len(edges)) if t>>i&1)
        return m.bit_count()
    return opt((1<<len(edges))-1),len(forb)

def main():
    alln=cert=deg2=ex=trips=gap=0;witness=None
    for n in range(1,7):
        pairs=list(combinations(range(n),2));tm=[sum(1<<pairs.index(e) for e in combinations(c,2)) for c in combinations(range(n),3)]
        for mask in range(1<<len(pairs)):
            if any(mask&t==t for t in tm):continue
            E=[e for i,e in enumerate(pairs) if mask>>i&1];tau,cost,deg=census(n,E);alln+=1
            b2=sum(sorted([1+x for x in deg]+[0],reverse=True)[:2]);lo=max(b2,n+len(E)-cost);hi=max(b2,n+len(E)-tau)
            assert lo<=hi
            if cost==tau:cert+=1
            if max(deg)<=2:assert cost==tau;deg2+=1
            if lo<hi:
                assert n==6 and len(E)==5 and sorted(deg)==[1,1,1,1,3,3]
                assert any(deg[i]==deg[j]==3 for i,j in E)
                gap+=1
                if witness is None:witness=(n,E,tau,cost,lo,hi)
            if n<=4:
                opt,tr=direct_opt(n,E);assert lo<=opt<=hi
                if cost==tau or lo==hi:assert opt==lo
                ex+=1;trips+=tr
    print('PASS ALL LABELLED TRIANGLE-FREE LEGAL GRAPHS n=1..6',alln)
    print('PASS PARTITION CERTIFICATE',cert,'MAX DEGREE TWO',deg2)
    print('PASS BFS EXHAUSTIVE EXACT OPTIMIZATION n=1..4',ex,'FORBIDDEN TRIPLES',trips)
    print('PARTITION BOUND GAP CASES',gap,'ALL ISOMORPHIC TO DOUBLE STAR (2,2)')
    n,E,tau,cost,lo,hi=witness;value,tr=direct_opt(n,E);assert (value,lo,hi,tr)==(8,8,9,92)
    print('PASS DOUBLE STAR REPRESENTATIVE BFS EXACT',value,'FORBIDDEN TRIPLES',tr)
    assert alln==cert+gap
    print('PASS ALL LABELLED TRIANGLE-FREE LEGAL GRAPHS n=1..6 CLOSED BY CERTIFICATE OR DOUBLE STAR',alln)
    checked=0
    for p in range(2,7):
        for q in range(2,7):
            n=p+q+2;E=[(0,1)]+[(0,i) for i in range(2,2+p)]+[(1,i) for i in range(2+p,n)]
            tau,cost,deg=census(n,E)
            assert (tau,cost)==(2,3)
            V=[0]+[1<<i for i in range(n)]+[(1<<i)|(1<<j) for i,j in E];full=(1<<len(V))-1
            masks=[sum(1<<i for i,x in enumerate(V) if (x^v).bit_count()<=1) for v in V]
            dom=[tuple(V[i] for i in t) for t in combinations(range(len(V)),3) if masks[t[0]]|masks[t[1]]|masks[t[2]]==full]
            assert dom==[(0,1,2)];checked+=1
    print('PASS DOUBLE STAR UNIQUE MINIMUM DOMINATING TRIPLE',checked)
    print('FINAL PASS AUTHOR-SIDE CORROBORATION ONLY / PRIVATE HOLD')
if __name__=='__main__':main()
